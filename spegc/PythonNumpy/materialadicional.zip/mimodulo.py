def suma(x, y):
    return x + y

class persona:
    def __init__(self, name):
        self.name = name
        
    def imprime(self):
        print(self.name)

valor = 1234