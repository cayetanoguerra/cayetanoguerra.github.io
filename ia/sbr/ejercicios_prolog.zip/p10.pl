%
%       EQUIPO DE BALONCESTO
%

% Jugador, altura, posición, calidad
player(p1, 208, pivot, 1).
player(p2, 186, base, 2).
player(p3, 192, alero, 2).
player(p4, 188, base, 1).
player(p5, 201, pivot, 3).
player(p6, 189, pivot, 1).
player(p7, 191, alero, 3).
player(p8, 197, alero, 1).
player(p9, 192, alero, 1).
player(p10, 194, alero, 2).

team(P1,P2,P3,P4,P5) :-
    player(P1,_,_,_),
    player(P2,_,_,_),
    player(P3,_,_,_),
    player(P4,_,_,_),
    player(P5,_,_,_),
    !.

% Tareas:
% 1) Todos los jugadores del equipo deben ser diferentes.
% 2) Siempre debe haber, al menos, un pivot.
% 3) No puede haber más de un jugador base en el equipo.
% 4) Devolver la media de altura del equipo.
% 5) La media de altura del equipo debe ser mayor que una dada.
% 6) Devolver la calidad media de del equipo.
% 7) Encontrar el quipo con la mayor altura.
% 8) Encontrar el quipo con la mejor combinación altura-calidad.
    