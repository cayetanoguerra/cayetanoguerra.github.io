covid :- 
    dolor_cabeza; (tos, fiebre). 

tos :-
    write('¿Tiene tos? (si/no)'),
    nl,
    read(Resp),
    Resp == si.

fiebre :-
    write('Póngase el termómetro. ¿Qué temperatura tiene?'),
    nl,
    read(T),
    T > 37.

dolor_cabeza :-
    write('¿Tiene dolor de cabeza? (si/no)'),
    nl,
    read(Resp),
    Resp == si.

%  Ejercicios 
% ------------------------------
%  Construye tu propio sistema experto de juguete.
