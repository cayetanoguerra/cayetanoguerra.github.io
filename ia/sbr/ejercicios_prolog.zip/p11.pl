:- dynamic minimo/1. 
:- dynamic nombre_objeto/1.

% En nuestro problema tenemos un conjunto de objetos.
% Cada objeto tiene un nombre y dos valores.
% Nuestro problema es saber qué objeto es el que tiene 
% el valor mínimo de la suma de sus dos valores.
 
objeto("objeto A", 3,4).
objeto("objeto B", 1,1).
objeto("objeto C", 6,3).
objeto("objeto D", 5,7).

go(N, X) :-
    assert(minimo(1000000)), % Utilizaremos los hechos 'minimo' y 'nombre_objeto' como variables auxiliares.
	assert(nombre_objeto("")),
    forall(search_object, true),
    nombre_objeto(N),
    minimo(X).


% Esta regla coloca en los hechos 'minimo' y 'nombre_objeto' los valores buscados
search_object :-
	objeto(Nombre,A,B),
    X is A+B,
	minimo(Min),
	(
    	Min > X
    ->  
    	(
        	retract(minimo(_)), % Quitamos el valor anterior
        	assert(minimo(X)), % Colocamos el nuevo valor
            retract(nombre_objeto(_)),
            assert(nombre_objeto(Nombre))
        )
    ).
    
    
    
    

