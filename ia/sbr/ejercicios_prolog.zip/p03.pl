es_un(perro, mamifero).
es_un(gato, mamifero).
es_un(aguila, ave).
es_un(condor, ave).
es_un(loro, ave).
es_un(sardina, pez).
es_un(atun, pez).

tiene(ave, alas).
tiene(ave, pico).
tiene(ave, plumas).

tiene(mamifero, pelo).

tiene(pez, escamas).
tiene(pez, aletas).

%  Ejercicios 
% ------------------------------
%  Pregunta qué clase de animal tiene 'pico'.
%  Crea una regla que diga si dos animales pertenecen a la misma clase.
%  Crea una regla que diga las propiedades que tenga un animal.



