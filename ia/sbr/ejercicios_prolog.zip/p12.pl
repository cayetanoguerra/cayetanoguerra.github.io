% Convertimos una string de entrada en una lista.
% Si ejecutamos:
% ?- go(L).
% Nos pedirá que introduzcamos algún texto. Si escribimos: abcd
% devolverá:
% L = [97, 98, 99, 100]

go(L) :-
    read(S),
    string_to_list(S, L).