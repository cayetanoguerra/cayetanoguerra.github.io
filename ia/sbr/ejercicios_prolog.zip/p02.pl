% prof(nombre, teléfono, despacho)

prof(pedro, 8744, d31).
prof(ana, 8741, d32).
prof(laura, 8744, d33).
prof(juan, 8655, d25).
prof(isabel, 6754, d32).
prof(manuel, 8752, d33).


%  Ejercicios 
% ------------------------------
% Pregunta por el tlf de Laura. 
% Pregunta por el despacho de Manuel.
% Pregunta quién es la persona que tiene el despacho d31.
% Crea una regla para saber qué profesores comparten despacho.
%  



