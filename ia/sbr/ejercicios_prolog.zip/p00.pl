hombre(socrates).

mortal(X) :- hombre(X).

