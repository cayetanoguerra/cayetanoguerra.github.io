person(pepe, 30, hombre).
person(ana, 24, mujer).
person(jose, 54, hombre).
person(pedro, 13, hombre).
person(maria, 38, mujer).

personas(Arg, L) :- findall(Nombre, person(Nombre, _, Arg), L).

edad_media(Edad_media) :-
    findall(Edad, person(_, Edad, _), L),
    length([1,2,3,4,5], S),
    sumlist(L, E),
    Edad_media is div(E,S).


% Ejemplos
% Obtenemos la lista con todas las personas que sean 'mujer'.
% ?- personas(mujer, L).
% Obtenemos la edad media de todas las personas.
% ?- edad_media(E).
% Ejercicio:
% 1) Modifica la segunda regla para que pueda calcular la edad media solo de los hombres o solo de las mujeres.



