% Medical Diagnosis Expert System in PROLOG
% To run, type go.

go:- 
    hypothesize(Disease),
    writeln('I think the patient has: '),
    writeln(Disease),
    undo.

% Medical Diagnosis Expert System in PROLOG
% To run, type go.

/* Hypothesis to be tested */
hypothesize(covid):- covid, !.
hypothesize(cold):- cold, !.
hypothesize(malaria):- malaria, !.
hypothesize(unknown).

/* Disease identification rules */
malaria :-
	verify(fever),
	verify(sweating),
	verify(headache),
	verify(nausea),
	verify(vomiting),
	verify(diarrhea),
    %------------------------------------------
	writeln('Advices and Sugestions:'),
	writeln('Take one of the following medicines: '),
	writeln('Chloroquin, Mefloquin or Atovaquon'),	
	writeln('Stay hydrated'),
	writeln('Please do not sleep in open air and cover your full skin.'),
	nl.

cold :-
	verify(headache),
	verify(runny_nose),
	verify(sneezing), 
	verify(sore_throat),
    %------------------------------------------
	writeln('Advices and Sugestions: '),	
	writeln('Nasal spray'),	
	writeln('Warm herbal tea'),	    
	writeln('Rest'),	
	writeln('Stay hydrated'),	
	writeln('Over-the-counter cold and cought medications'),
	nl.

covid :-
	verify(fever),
	verify(dry_cough),
	verify(shortness_of_breath),
    %------------------------------------------
	writeln('Advices and Sugestions: '),	
	writeln('Quarantine for two weeks'),		
	writeln('Prevent dehydrations'),		
	writeln('Monitor your Symptoms'),	
	writeln('Treat weak symptoms with over-the-counter cold and cought medications'),		
	writeln('If the symptoms get worse, call your doctor right away'),
	nl.	

ask(Question) :-
	writeln('Does the patient have the following symptom:'),
	writeln(Question),
	writeln('?'),
	read(Response),	
	(   
        (Response == yes ; Response == y ; Response == si ; Response == s)
	-> 
        assert(yes(Question))
    ;
	    assert(no(Question)), fail
    ).

:- dynamic yes/1, no/1.

/* How to verify something */
verify(S) :- 
    (yes(S) -> true ; (no(S) -> fail; ask(S))). 

/* Undo all yes/no assertations */
undo :- retract(yes(_)),fail.
undo :- retract(no(_)),fail.
undo. 