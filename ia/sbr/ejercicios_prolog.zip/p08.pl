
% PEOPLE

person(dni1, "Ana Pérez", [lun_09_00, lun_10_00, mar_11_00, mie_12_00, vie_13_00]).
person(dni2, "Juan Serrano", [lun_09_00, lun_12_00, mar_11_00, mie_12_00, jue_12_00]).
person(dni3, "María Martínez", [mar_11_00, mie_12_00, jue_12_00]).

person(dni4, "David Sánchez", [lun_09_00, lun_10_00, mar_11_00, mie_12_00, vie_13_00]).
person(dni5, "Isabel Mateos", [lun_09_00, lun_12_00, mar_11_00, mie_12_00, jue_12_00]).

person(dni6, "Pedro Viera", [lun_09_00, lun_10_00, mar_11_00, mie_12_00, vie_13_00]).
person(dni7, "Manuel Vegaº", [lun_09_00, lun_12_00, mar_11_00, mie_12_00, jue_12_00]).
person(dni8, "Dolores Santana", [mar_11_00, mie_12_00, jue_12_00]).

% ROLES

is_a(dni1, surgeon).
is_a(dni2, surgeon).
is_a(dni3, surgeon).

is_a(dni4, anaesthetist).
is_a(dni5, anaesthetist).

is_a(dni6, nurse).
is_a(dni7, nurse).
is_a(dni8, nurse).

% RULES -------------------------------------------------

match(L, Response) :-
    [Head|Tail] = L,
    forall(aux(_), retract(aux(_))),
    person(Head, _, Hours),
    assert(aux(Hours)),
    forall(
        person(D, N, H),        
        (
            member(D,L)
        ->
            (
                aux(X),
                intersection(X, H, L2),
                retract(aux(X)),
                assert(aux(L2))
            )
        ;
            true   
        )
    ),
    aux(Response),
    retract(aux(Response)).
    
    



