%
%       EQUIPO DE BALONCESTO
%

% Jugador, altura, posición, calidad
player(p1, 208, pivot, 1).
player(p2, 186, base, 2).
player(p3, 192, alero, 2).
player(p4, 188, base, 1).
player(p5, 201, pivot, 3).
player(p6, 189, pivot, 1).
player(p7, 191, alero, 3).
player(p8, 197, alero, 1).
player(p9, 192, alero, 1).
player(p10, 194, alero, 2).

diferente(A,B,C,D,E) :-
    dif(A,B),
    dif(A,C),
    dif(A,D),
    dif(A,E),
    dif(B,C),
    dif(B,D),
    dif(B,E),
    dif(C,D),
    dif(C,E),
    dif(D,E).

team(P1,P2,P3,P4,P5,A_media,A_min) :-
    player(P1,A1,pivot,_),
    player(P2,A2,_,_),
    player(P3,A3,R3,_),dif(R3,base),
    player(P4,A4,R4,_),dif(R4,base),
    player(P5,A5,R5,_),dif(R5,base),
    diferente(P1,P2,P3,P4,P5),
    A is A1+A2+A3+A4+A5,
    A_media is div(A,5),
    A_media > A_min,
    !.

personas(Arg, L) :- findall(Nombre, person(Nombre, _, Arg), L).

max_altura(M,L) :-
    findall(A_media, team(P1,P2,P3,P4,P5,A_media,0),L),
    max_list(L, M).
    

% Tareas:
% 1) Todos los jugadores del equipo deben ser diferentes.
% 2) Siempre debe haber, al menos, un pivot.
% 3) No puede haber más de un jugador base en el equipo. Es decir, hay uno o ninguno.
% 4) Devolver la media de altura del equipo.
% 5) La media de altura del equipo debe ser mayor que una dada.
% 6) Devolver la calidad media de del equipo.
% 7) Encontrar el quipo con la mayor altura.
% 8) Encontrar el quipo con la mejor combinación altura-calidad.
    