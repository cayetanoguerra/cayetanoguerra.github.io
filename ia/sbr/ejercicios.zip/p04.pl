suma(X,Y,R) :- R is X + Y.

factorial(0, R) :- R is 1.
factorial(N, R) :-
    N > 0,
    N1 is N - 1,
    factorial(N1, F1),
    R is N * F1.


%  Ejercicios 
% ------------------------------
%  Construye una regla para devolver la resta de dos números.
%  Construye una regla que devuelva la serie de Fibonacci de un número.



