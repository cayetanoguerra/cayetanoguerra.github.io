
hombre(socrates).

mortal(socrates) :- hombre(socrates).
 

