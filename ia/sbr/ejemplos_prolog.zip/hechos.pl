% Crear una lista a partir de un conjunto de hechos

man(john).
man(carl).
woman(mary).
woman(rose).

people(L) :- findall(X, (man(X) ; woman(X)), L).

men(L) :- findall(X, man(X), L).

women(L) :- findall(X, woman(X), L).




