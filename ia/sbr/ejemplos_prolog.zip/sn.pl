
isa("iPhone 11", mobile-phone).
isa("iPhone 6s", mobile-phone).
isa("Galaxy Note 10+", mobile-phone).
isa("Mi Mix 3 5G", mobile-phone).

isa("iPad Pro", tablet).
isa("Galaxy Tab S5e", tablet).
isa("Microsoft Surface Pro 6", tablet).
isa("MediaPad M5", tablet).

isa(mobile-phone, device).
isa(tablet, device).

isa(device, object).

prop("iPhone 11", [price(1259), camera(12), manufacturer(apple)]).
prop("iPhone 6s", [price(550), manufacturer(apple)]).
prop("Galaxy Note 10+", [price(899), camera(10)]).
prop("Mi Mix 3 5G", [price(599), camera(8)]).

prop("iPad Pro", [price(1100), camera(10), manufacturer(apple)]).
prop("Galaxy Tab S5e", [price(950), camera(10), manufacturer(samsung)]).
prop("Microsoft Surface Pro 6", [manufacturer(microsoft)]).
prop("MediaPad M5", []).

is_a(X,Y) :- 
    isa(X,Y).

is_a(X, Y) :-
    isa(X, Z),
    is_a(Z, Y).

port(X, P) :-
    prop(X,L),
    member(manufacturer(Y), L),
    Y == apple,
    P = "usb".


% is_a(X, mobile-phone), prop(X,L), member(camera(Y),L), Y>8.   Search all mobiles with a camera greater than 8 megapixels
