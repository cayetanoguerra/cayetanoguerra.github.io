% UNIFICACION

fruta(manzana).
fruta(naranja).
fruta(platano).

carne(pollo).
carne(vaca).
carne(cerdo).
carne(caballo).

comida(paella).
comida(pulpo).

comida(X) :- fruta(X).
comida(X) :- carne(X).


