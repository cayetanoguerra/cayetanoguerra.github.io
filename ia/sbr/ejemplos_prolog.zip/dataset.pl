prof("Pedro", 8744, d31).
prof("Ana", 8741, d32).
prof("Laura", 8744, d33).
prof("Antonio", 8741, d32).
prof("Juan", 8655, d25).
prof("Isabel",nil, d32).

telephone(X, T) :- prof(X, _, D), prof(Y, T, D).



