
isa("iPhone 11", mobile-phone).
isa("iPhone 6s", mobile-phone).
isa("Galaxy Note 10+", mobile-phone).
isa("Mi Mix 3 5G", mobile-phone).

isa(mobile-phone, device).

prop("iPhone 11", price, 1259).
prop("iPhone 6s", price, 550).
prop("Galaxy Note 10+", price, 899).
prop("Mi Mix 3 5G", price, 599).


appearance(Thing, Colour) :-
    hasa(Thing, colour(Colour)).

appearance(Name, Colour) :-
    isa(Name, Thing),
    hasa(Thing, colour(Colour)).


is_a(X,Y) :- 
    isa(X,Y).

is_a(X, Y) :-
    isa(X, Z),
    is_a(Z, Y).

has_a(X, Thing) :-
    is_a(X, Y),
    hasa(Y, Thing).