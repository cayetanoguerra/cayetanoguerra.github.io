person(pepe, 30, hombre).
person(ana, 24, mujer).
person(jose, 54, hombre).
person(pedro, 13, hombre).
person(maria, 38, mujer).

personas(Arg, LIST) :- findall(Nombre, person(Nombre, _, Arg), LIST).

edad_promedio(Edad_media) :- aggregate(sum, person(_,E,_), LIST).

%(Nombre, person(Nombre, _, Arg), LIST).

% Ejemplos
% Obtenemos la lista con todas las personas que sean 'mujer'.
% ?- personas(mujer, L).
% Obtenemos la edad media de todas las personas.
% ?- 



